"""tests of jupyterlite"""
