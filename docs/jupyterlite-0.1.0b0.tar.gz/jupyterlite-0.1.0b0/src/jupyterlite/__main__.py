if __name__ == "__main__":
    from jupyterlite.app import main

    main()
