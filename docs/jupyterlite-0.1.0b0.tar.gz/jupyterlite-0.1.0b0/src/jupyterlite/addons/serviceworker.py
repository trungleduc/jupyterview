"""a JupyterLite addon for enabling serviceworker support

TODO: this would prepare the Web Manifest, and likely update some configurations

https://github.com/SchemaStore/schemastore/blob/master/src/schemas/json/web-manifest.json
"""
