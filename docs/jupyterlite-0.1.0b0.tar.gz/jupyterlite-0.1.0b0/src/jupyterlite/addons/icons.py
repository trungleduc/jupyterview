"""a JupyterLite addon for customizing favicons

TODO:
  - this should do some best-effort image conversions.
  - may also impact `serviceworker.py`
"""
